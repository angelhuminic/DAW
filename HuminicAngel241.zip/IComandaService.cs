﻿using Microsoft.EntityFrameworkCore;

namespace examen
{
    public interface IComandaService
    {
        Task<IEnumerable<Comanda>> GetComenziAsync();
        Task<Comanda> GetComandaByIdAsync(int comandaId);
        Task AddComandaAsync(Comanda comanda);
        Task UpdateComandaAsync(Comanda comanda);
        Task DeleteComandaAsync(int comandaId);
    }
}
