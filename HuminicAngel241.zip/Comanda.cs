﻿using examen;
using Microsoft.EntityFrameworkCore;

namespace examen
{
    public class Comanda
    {
        public int id_comanda { get; set; }
        public DateTime Data { get; set; }
        public int id_utilizator { get; set; }
        public Utilizator Utilizator { get; set; }
        public ICollection<ProdusComanda> ProduseComanda { get; set; }
        public ICollection<Produs> Produse { get; set; }
    }

}
