﻿using Microsoft.AspNetCore.Mvc;

namespace examen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilizatorController : ControllerBase
    {
        private readonly IUserService _userService;

        public UtilizatorController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Utilizator>>> GetUsers()
        {
            var users = await _userService.GetUsersAsync();
            return Ok(users);
        }

    }
}
