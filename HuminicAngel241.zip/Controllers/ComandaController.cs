﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace examen.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ComandaController : ControllerBase
    {
        private readonly IComandaService _comandaService;

        public ComandaController(IComandaService comandaService)
        {
            _comandaService = comandaService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Comanda>>> GetComenzi()
        {
            var comenzi = await _comandaService.GetComenziAsync();
            return Ok(comenzi);
        }

    }
}
