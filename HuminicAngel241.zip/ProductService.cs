﻿using System;
using Microsoft.EntityFrameworkCore;


namespace examen
{
    public interface IProductService
    {
        Task<IEnumerable<Produs>> GetProductsAsync();
        Task AddProductAsync(Produs produs);
    }

    public class ProductService : IProductService
    {
  
        private readonly AppDbContext _context;

            public ProductService(AppDbContext context)
            {
                _context = context;
            }

            public async Task<IEnumerable<Produs>> GetProductsAsync()
            {
                return await _context.Produse.ToListAsync();
            }

            public async Task AddProductAsync(Produs produs)
            {
                _context.Produse.Add(produs);
                await _context.SaveChangesAsync();
            }

            // alte implementări ale metodelor interfeței
        }
}

