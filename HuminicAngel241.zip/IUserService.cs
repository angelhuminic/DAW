﻿using Microsoft.EntityFrameworkCore;

namespace examen
{
    public interface IUserService
    {
        Task<IEnumerable<Utilizator>> GetUsersAsync();
        Task<Utilizator> GetUserByIdAsync(int userId);
        Task AddUserAsync(Utilizator user);
        Task UpdateUserAsync(Utilizator user);
        Task DeleteUserAsync(int userId);
    }
}
