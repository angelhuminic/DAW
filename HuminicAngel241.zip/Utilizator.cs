﻿namespace examen
{
    public class Utilizator
    {
        public int id_utilizator { get; set; }
        public string nume_utilizator { get; set; }
        public string prenume_utilizator { get; set; }
        public ICollection<Comanda> Comenzi { get; set; }
    }
}
