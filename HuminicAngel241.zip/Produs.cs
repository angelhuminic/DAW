﻿using Microsoft.EntityFrameworkCore;

namespace examen
{
    public class Produs
    {
        public int id_produs { get; set; }
        public string nume_produs { get; set; }
        public int pret_produs { get; set; }
        public int rating_produs { get; set; }
        public object ProduseComanda { get; internal set; }
    }
}
