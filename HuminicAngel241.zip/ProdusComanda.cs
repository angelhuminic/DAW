﻿namespace examen
{
    public class ProdusComanda
    {
        public int id_produscomanda { get; set; }
        public int id_comanda { get; set; }
        public Comanda Comanda { get; set; }
        public int ProdusId { get; set; }
        public Produs Produs { get; set; }
    }
}
